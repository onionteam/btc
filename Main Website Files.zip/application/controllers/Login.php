<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends MY_Controller{
 public function __construct()
 {
  parent::__construct();
  $this->load->model('login_model');
  $this->load->model('user_model');
  //$this->clear_cache();
 }
 public function login()
 {
  if(($this->session->userdata('user_email')!=""))
  {
   $this->welcome();
  }
  else{
   $data['title']= constant('WEBSITE_TITLE');

   $this->load->view('templates/header_login',$data);
   $this->load->view("pages/login", $data);
   $this->load->view('templates/footer',$data);
  }
 }

 public function set_timezone() {

  $this->session->set_userdata('user_timezone', $_GET['time']);

 }

  //Main page controller
 public function welcome($error = null)
 {


  $data['title']= WEBSITE_TITLE;

  $data['products']= $this->user_model->get_products();

  $data['total_earnings']= $this->user_model->get_total_earnings();

  $data['total_sales']= $this->user_model->get_total_sales();

  $data['today_earnings']= $this->user_model->get_today_earnings();

  $data['today_sales']= $this->user_model->get_today_sales();

  $data['notifications']= $this->user_model->get_notifications();

  $data['timezone'] = $this->session->userdata('user_timezone');

  $data['payment_settings'] = $this->user_model->get_payment_settings();

  $data['coupons'] = $this->user_model->get_all_coupons();

  $data['user_model']= $this->user_model;

  //The left side nav
  $data['left_side_nav'] = $this->load->view('templates/side_menu', $data, true);

  //User dashboard
  $data['user_dashboard'] = $this->load->view('templates/user_dashboard', $data, true);

  $this->load->view('templates/header_dashboard',$data);
  $this->load->view("pages/dashboard", $data);
  $this->load->view('templates/footer_dashboard',$data);


 }
 public function do_login()
 {
  $email = $this->input->post('email');
  $password = md5($this->input->post('pass'));

  $result = $this->login_model->login($email,$password);


  if($result) {

    //echo "wrong password";
    //redirect(base_url() . 'login');
    echo "true";

  }
  else {

    echo "Wrong Password";

  }

 }

 public function do_logout()
 {
  $newdata = array(
  'user_id'   =>'',
  'user_name'  =>'',
  'user_email'     => '',
  'logged_in' => FALSE,
  'user_timezone' => ''
  );
  $this->session->unset_userdata($newdata );
  $this->session->sess_destroy();
  //$this->index();
  redirect(base_url() . 'login');
  
 }




}#End User controller