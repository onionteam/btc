<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Home extends MY_Controller{

public function __construct() {

  parent::__construct();
  $this->load->model('login_model');
  $this->load->model('user_model');

}

public function index() {

  $data['title']= constant('WEBSITE_TITLE');

  $this->load->view('templates/header_home',$data);
  $this->load->view("pages/home", $data);
  $this->load->view('templates/footer',$data);
  
}




} //End controller